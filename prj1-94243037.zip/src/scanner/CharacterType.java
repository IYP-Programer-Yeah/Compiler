package scanner;

/**
 * Created by HoseinGhahremanzadeh on 3/3/2017.
 */
public enum CharacterType {
    u, U, L, u8, none
}
