package scanner;

/**
 * Created by HoseinGhahremanzadeh on 3/2/2017.
 */
public class RealNumberSize {
    public static final int FloatSize = 32;
    public static final int DoubleSize = 64;
}
