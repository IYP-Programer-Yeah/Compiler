package scanner;

/**
 * Created by HoseinGhahremanzadeh on 2/28/2017.
 */
public class IntegerSize {
    public static final int IntSize = 32;
    public static final int LongSize = 32;
    public static final int LongLongSize = 64;
}
